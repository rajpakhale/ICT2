﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Json;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using MobileStoreAPIClient.Models;
using Newtonsoft.Json;

namespace MobileStoreAPIClient.Controllers
{
    public class BillsController : Controller
    {
        private readonly StoreDBContext _context;
        string url = "https://localhost:44394/api/Bills/";
        HttpClient client = new HttpClient();

        public BillsController(StoreDBContext context)
        {
            _context = context;
        }

        // GET: Bills
        public async Task<IActionResult> Index(string searchby,string productlist,string customerlist)
        {
            ViewData["productlist"] = new SelectList(_context.Products, "ProductName", "ProductName",productlist);
            ViewData["customerlist"] = new SelectList(_context.Customers, "CustomerName", "CustomerName", customerlist);

            if(searchby == "products")
            {
                var productreport = JsonConvert.DeserializeObject<List<Bills>>(await client.GetStringAsync(url + "productreport" + "?productname=" + productlist)).ToList();
                return View(productreport);
            }

            if(searchby == "customers")
            {
                var customerreport = JsonConvert.DeserializeObject<List<Bills>>(await client.GetStringAsync(url + "customerreport" + "?customername=" + customerlist)).ToList();
                return View(customerreport);
            }
            var bills = JsonConvert.DeserializeObject<List<Bills>>(await client.GetStringAsync(url)).ToList();
            //var storeDBContext = _context.Bills.Include(b => b.Customer).Include(b => b.Product);
            return View(bills);
        }

        // GET: Bills/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            //var bills = await _context.Bills
            //    .Include(b => b.Customer)
            //    .Include(b => b.Product)
            //    .FirstOrDefaultAsync(m => m.BillNo == id);
            var bills = JsonConvert.DeserializeObject<Bills>(await client.GetStringAsync(url + id.ToString()));
            if (bills == null)
            {
                return NotFound();
            }

            return View(bills);
        }

        // GET: Bills/Create
        public IActionResult Create()
        {
            ViewData["CustomerId"] = new SelectList(_context.Customers, "CustomerId", "CustomerName");
            ViewData["ProductId"] = new SelectList(_context.Products, "ProductId", "ProductName");
            return View();
        }

        // POST: Bills/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("BillNo,ProductId,CustomerId,Date")] Bills bills)
        {
            if (ModelState.IsValid)
            {
                bills.Date = DateTime.Now;
                await client.PostAsJsonAsync(url, bills);
                //_context.Add(bills);
                //await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["CustomerId"] = new SelectList(_context.Customers, "CustomerId", "CustomerName", bills.CustomerId);
            ViewData["ProductId"] = new SelectList(_context.Products, "ProductId", "ProductName", bills.ProductId);
            return View(bills);
        }

        // GET: Bills/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var bills = JsonConvert.DeserializeObject<Bills>(await client.GetStringAsync(url + id.ToString()));
            if (bills == null)
            {
                return NotFound();
            }
            ViewData["CustomerId"] = new SelectList(_context.Customers, "CustomerId", "CustomerName", bills.CustomerId);
            ViewData["ProductId"] = new SelectList(_context.Products, "ProductId", "ProductName", bills.ProductId);
            return View(bills);
        }

        // POST: Bills/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("BillNo,ProductId,CustomerId,Date")] Bills bills)
        {
            if (id != bills.BillNo)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    await client.PutAsJsonAsync(url+id.ToString(),bills);
                    //_context.Update(bills);
                    //await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!BillsExists(bills.BillNo))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["CustomerId"] = new SelectList(_context.Customers, "CustomerId", "CustomerName", bills.CustomerId);
            ViewData["ProductId"] = new SelectList(_context.Products, "ProductId", "ProductName", bills.ProductId);
            return View(bills);
        }

        // GET: Bills/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var bills = JsonConvert.DeserializeObject<Bills>(await client.GetStringAsync(url + id.ToString()));
            if (bills == null)
            {
                return NotFound();
            }

            return View(bills);
        }

        // POST: Bills/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            await client.DeleteAsync(url + id.ToString());
            //var bills = await _context.Bills.FindAsync(id);
            //_context.Bills.Remove(bills);
            //await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool BillsExists(int id)
        {
            return _context.Bills.Any(e => e.BillNo == id);
        }
    }
}
